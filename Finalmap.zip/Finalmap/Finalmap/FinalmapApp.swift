//
//  FinalmapApp.swift
//  Finalmap
//
//  Created by Muhammad Aun e Ali Mirza on 10/11/24.
//

import SwiftUI

@main
struct FinalmapApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
