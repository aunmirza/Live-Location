import SwiftUI
import MapKit
import CoreLocation

// Custom struct for map annotations
struct Landmark: Identifiable {
    let id = UUID()
    let mapItem: MKMapItem
    
    var coordinate: CLLocationCoordinate2D {
        mapItem.placemark.coordinate
    }
}

class LocationManager: NSObject, ObservableObject, CLLocationManagerDelegate {
    @Published var region = MKCoordinateRegion(
        center: CLLocationCoordinate2D(latitude: 40.8518, longitude: 14.2681), // Naples coordinates
        span: MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05)
    )
    @Published var landmarks: [Landmark] = []
    
    private var locationManager = CLLocationManager()

    override init() {
        super.init()
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.requestWhenInUseAuthorization()
    }
    
    func startUpdatingLocation() {
        locationManager.startUpdatingLocation()
    }
    
    func stopUpdatingLocation() {
        locationManager.stopUpdatingLocation()
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if let userLocation = locations.last {
            region = MKCoordinateRegion(
                center: userLocation.coordinate,
                span: MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05)
            )
            stopUpdatingLocation()
        }
    }
    
    func searchForPlaces(query: String) {
        let searchRequest = MKLocalSearch.Request()
        searchRequest.naturalLanguageQuery = query
        searchRequest.region = region
        
        let search = MKLocalSearch(request: searchRequest)
        search.start { response, error in
            if let error = error {
                print("Search error: \(error.localizedDescription)")
                return
            }
            
            if let response = response {
                DispatchQueue.main.async {
                    self.landmarks = response.mapItems.map { Landmark(mapItem: $0) }
                    if self.landmarks.isEmpty {
                        print("No results found for query: \(query)")
                    }
                }
            }
        }
    }
}

struct ContentView: View {
    @StateObject private var locationManager = LocationManager()
    @State private var searchQuery = ""
    
    var body: some View {
        ZStack {
            // Map view with full screen layout
            Map(coordinateRegion: $locationManager.region, showsUserLocation: true, annotationItems: locationManager.landmarks) { landmark in
                MapAnnotation(coordinate: landmark.coordinate) {
                    VStack {
                        Image(systemName: "mappin.circle.fill")
                            .foregroundColor(.red)
                        Text("MyBin")  // Use a static label "MyBin" for each annotation
                            .font(.caption)
                            .foregroundColor(.black)
                    }
                }
            }
            .edgesIgnoringSafeArea(.all)  // Makes map full screen
            
            VStack {
                // Search bar with black background and white input area
                HStack {
                    TextField("Search for places", text: $searchQuery)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .padding(.leading, 8)
                        .background(Color.white) // Makes text input area white
                        .cornerRadius(8)
                        .padding(.horizontal, 8)
                    
                    Button(action: {
                        locationManager.searchForPlaces(query: searchQuery)
                    }) {
                        Image(systemName: "magnifyingglass")
                            .foregroundColor(.white)
                            .padding(10)
                            .background(Color.blue)
                            .clipShape(Circle())
                    }
                    .padding(.trailing, 8)
                }
                .padding()
                .background(Color.black) // Makes the search bar background black
                .cornerRadius(8)
                .padding(.top, 50)
                
                Spacer()
                
                // Show Current Location Button
                Button(action: {
                    locationManager.startUpdatingLocation()
                }) {
                    Text("Show My Current Location")
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(8)
                }
                .padding(.horizontal)
                .padding(.bottom, 30)
            }
        }
        .background(Color.white) // Ensures the entire view background is white
    }
}
